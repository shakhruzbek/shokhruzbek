let countries = [], 
    currentQuestionIndex = 0, // Savolning boshlang'ich indeksi
    score = 0, // O'yinchining umumiy balli
    playerName = "", // O'yinchi ismi
    timerInterval, // Taymerni boshqarish uchun interval
    timeLeft = 15; // Har bir savolga qoldirilgan vaqt
const leaderboard = JSON.parse(localStorage.getItem("leaderboard")) || {}; 

// API orqali davlatlar haqidagi ma'lumotlar
axios.get("https://restcountries.com/v3.1/all")
  .then((response) => {
    countries = response.data;
  })
  .catch(error => console.error("Error fetching countries:", error)); // Xatolik bo'lsa konsolga chiqarish

// O'yinni boshlash funksiyasi
function startGame() {
    playerName = document.getElementById("player-name").value.trim(); 
    if (!playerName) return alert("Brat boshlash uchun ismizi kriting e.g: Eshmat !"); // Agar ism kiritilmasa, ogohlantirish
    document.getElementById("start-screen").style.display = "none"; 
    document.getElementById("quiz-screen").style.display = "block"; 
    resetGame(); // O'yinni reset qilish
    loadNextQuestion(); // Keyingi savolni yuklash
}

// O'yinni boshqatdan boshlash
function resetGame() {
    currentQuestionIndex = 0; // Savolning indeksi
    score = 0; // Hisobni yangilash
    timeLeft = 15; // Vaqtni tiklash
    updateScore(); // Hisobni yangilash
}

// Keyingi savolni yuklash
function loadNextQuestion() {
    if (currentQuestionIndex >= 10) return endGame(); // Agar savollar tugagan bo'lsa, o'yinni tugatish
    const country = getRandomCountry(); // Tasodifiy davlatni olish
    const correctCapital = country.capital?.[0] || "Unknown"; // To'g'ri poytaxt
    const options = generateOptions(correctCapital); // Javob variantlari
    document.getElementById("country-flag").src = country.flags.png; // Davlat bayrog'ini ko'rsatish
    document.getElementById("country-name").textContent = country.name.common; // Davlat nomini ko'rsatish
    document.getElementById("options").innerHTML = options.map(option =>
        `<button onclick="checkAnswer('${option}', '${correctCapital}', this)">${option}</button>`
    ).join(""); // Variantlar tugma sifatida
    timeLeft = 15; // Vaqtni tiklash
    startTimer(); // Taymerni boshlash
}

// Tasodifiy davlatni olish
function getRandomCountry() {
    return countries[Math.floor(Math.random() * countries.length)]; // Tasodifiy davlatni tanlash
}

// To'g'ri javob va yolg'on variantlarni yaratish
function generateOptions(correct) {
    const options = [correct]; // To'g'ri javobni variantlar ro'yxatiga qo'shish
    while (options.length < 4) { // 4 ta variant kerak
        const randomOption = getRandomCountry().capital?.[0] || "Unknown"; // Yangi tasodifiy poytaxt
        if (!options.includes(randomOption)) options.push(randomOption); // Yangi variantni qo'shish
    }
    return options.sort(() => Math.random() - 0.5); // Variantlarni aralashtirish
}

// Javobni tekshirish
function checkAnswer(selected, correct, button) {
    clearInterval(timerInterval); // Taymerni to'xtatish
    const buttons = document.querySelectorAll("#options button"); 
    buttons.forEach(btn => {
        if (btn.textContent === correct) btn.classList.add("correct"); // To'g'ri javobni "correct" sinfi bilan belgilash
    });
    if (selected !== correct) button.classList.add("wrong"); // Yolg'on javobni "wrong" sinfi bilan belgilash
    else score++; // To'g'ri javob bo'lsa, ballni oshirish
    updateScore(); // Hisobni yangilash
    currentQuestionIndex++; // Savol indeksini oshirish
    setTimeout(loadNextQuestion, 2000); // 2 soniyadan keyin keyingi savolni yuklash
}

// Hisobni yangilash
function updateScore() {
    document.getElementById("score").textContent = `Score: ${score}`; // Hisobni ekranda ko'rsatish
}

// Taymerni boshlash
function startTimer() {
    clearInterval(timerInterval); // Eski taymerni to'xtatish
    document.getElementById("timer").textContent = timeLeft; // Vaqtni ekranda ko'rsatish
    timerInterval = setInterval(() => {
        timeLeft--; // Har bir soniyada vaqtni kamaytirish
        document.getElementById("timer").textContent = timeLeft; // Vaqtni yangilash
        if (timeLeft <= 0) { // Agar vaqt tugasa
            clearInterval(timerInterval); // Taymerni to'xtatish
            currentQuestionIndex++; // Savol indeksini oshirish
            loadNextQuestion(); // Keyingi savolni yuklash
        }
    }, 1000); // Har bir soniyada qaytadan ishga tushirish
}

// O'yinni tugatish
function endGame() {
    document.getElementById("quiz-screen").style.display = "none"; // Savollar ekranini yashirish
    document.getElementById("end-screen").style.display = "block"; // Tugash ekranini ko'rsatish
    if (!leaderboard[playerName] || leaderboard[playerName] < score) leaderboard[playerName] = score; // Agar yangi ball yuqori bo'lsa, leaderboardni yangilash
    localStorage.setItem("leaderboard", JSON.stringify(leaderboard)); // Leaderboardni saqlash
    const bestScore = Math.max(...Object.values(leaderboard)); // Eng yuqori ballni topish
    const bestPlayer = Object.keys(leaderboard).find(name => leaderboard[name] === bestScore); // Eng yaxshi o'yinchini topish
    document.getElementById("final-message").textContent = `Good job, ${playerName}! Your score: ${score}`; // Tugash xabarini ko'rsatish
    document.getElementById("best-player").textContent = `Best player: ${bestPlayer} with ${bestScore} points`; // Eng yaxshi o'yinchini ko'rsatish
}

// O'yinni qayta boshlash
function playAgain() {
    document.getElementById("end-screen").style.display = "none"; // Tugash ekranini yashirish
    document.getElementById("quiz-screen").style.display = "block"; // Savollar ekranini ko'rsatish
    resetGame(); // O'yinni reset qilish
    loadNextQuestion(); // Keyingi savolni yuklash
}

// Modalni ko'rsatish
function showLeaderboard() {
    const leaderboardContent = Object.entries(leaderboard)
        .map(([name, points]) => `${name}: ${points}`) // Leaderboardni string ko'rinishiga keltirish
        .join("\n"); // Yangi qator bilan ajratish

    document.getElementById("leaderboard-content").textContent = leaderboardContent; // Leaderboardni ekranga chiqarish

    const modal = document.getElementById("leaderboard-modal");
    modal.style.display = "block"; // Modalni ko'rsatish
    setTimeout(() => {
        modal.style.opacity = 1; // Modalning ko'rinmasidan ko'rinarli holatga o'tishi
    }, 50); 
}

// Modalni yopish (tugma bosish orqali)
document.getElementById("close-modal").onclick = function() {
    const modal = document.getElementById("leaderboard-modal");
    modal.style.opacity = 0; // Modalni ko'rinmas qilish
    setTimeout(() => {
        modal.style.display = "none"; // Modalni yashirish
    }, 1000); 
}

// Modalni tashqaridan bosish orqali yopish
window.onclick = function(event) {
    const modal = document.getElementById("leaderboard-modal");
    if (event.target === modal) { // Agar foydalanuvchi modal tashqarisiga bossa
        modal.style.opacity = 0; // Modalni ko'rinmas qilish
        setTimeout(() => {
            modal.style.display = "none"; // Modalni yashirish
        }, 1000); // 1 soniya kutish
    }
};